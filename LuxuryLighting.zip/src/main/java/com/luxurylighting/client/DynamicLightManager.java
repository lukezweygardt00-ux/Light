package com.luxurylighting.client;

import com.luxurylighting.LuxuryLighting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Client only. Keeps a list of virtual light sources that live outside the world's light engine. */
@Mod.EventBusSubscriber(modid = LuxuryLighting.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DynamicLightManager {
    private static final double SCAN_RADIUS = 48.0;

    private static final class Source {
        double x, y, z;
        int level;
    }

    // Read by the render thread, written on the client tick thread.
    private static volatile Source[] active = new Source[0];
    private static final Map<Integer, long[]> last = new HashMap<>(); // id -> {blockPos, level}

    private DynamicLightManager() {}

    public static int emission(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return 0;
        if (stack.getItem() instanceof BlockItem bi) {
            BlockState s = bi.getBlock().defaultBlockState();
            return s.getLightEmission();
        }
        return 0;
    }

    /** Brightest light level (0-15) our virtual sources give at a block position. */
    public static int levelAt(BlockPos pos) {
        Source[] src = active;
        if (src.length == 0) return 0;
        int best = 0;
        double px = pos.getX() + 0.5, py = pos.getY() + 0.5, pz = pos.getZ() + 0.5;
        for (Source s : src) {
            double dx = px - s.x, dy = py - s.y, dz = pz - s.z;
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            int v = s.level - (int) Math.floor(d);
            if (v > best) best = v;
        }
        return best;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        try {
            tick();
        } catch (Throwable t) {
            active = new Source[0];
        }
    }

    private static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            active = new Source[0];
            last.clear();
            return;
        }
        List<Source> list = new ArrayList<>();
        Set<Integer> seen = new HashSet<>();

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e.distanceToSqr(mc.player) > SCAN_RADIUS * SCAN_RADIUS) continue;
            int lvl = 0;
            if (e instanceof ItemEntity ie) {
                lvl = emission(ie.getItem());
            } else if (e instanceof LivingEntity le) {
                lvl = Math.max(emission(le.getMainHandItem()), emission(le.getOffhandItem()));
            }
            if (lvl <= 0) continue;

            Source s = new Source();
            s.x = e.getX();
            s.y = e.getY() + e.getBbHeight() * 0.6;
            s.z = e.getZ();
            s.level = lvl;
            list.add(s);

            int id = e.getId();
            seen.add(id);
            long bp = BlockPos.asLong((int) Math.floor(s.x), (int) Math.floor(s.y), (int) Math.floor(s.z));
            long[] prev = last.get(id);
            if (prev == null || prev[0] != bp || prev[1] != lvl) {
                if (prev != null) dirty(BlockPos.of(prev[0]), (int) prev[1]);
                dirty(BlockPos.of(bp), lvl);
                last.put(id, new long[]{bp, lvl});
            }
        }

        // sources that vanished (torch dropped/picked up, put away, entity gone)
        var it = last.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            if (!seen.contains(en.getKey())) {
                dirty(BlockPos.of(en.getValue()[0]), (int) en.getValue()[1]);
                it.remove();
            }
        }
        active = list.toArray(new Source[0]);
    }

    private static void dirty(BlockPos c, int level) {
        var lr = Minecraft.getInstance().levelRenderer;
        if (lr == null) return;
        int r = level + 1;
        int minX = (c.getX() - r) >> 4, maxX = (c.getX() + r) >> 4;
        int minY = (c.getY() - r) >> 4, maxY = (c.getY() + r) >> 4;
        int minZ = (c.getZ() - r) >> 4, maxZ = (c.getZ() + r) >> 4;
        for (int x = minX; x <= maxX; x++)
            for (int y = minY; y <= maxY; y++)
                for (int z = minZ; z <= maxZ; z++)
                    try { lr.setSectionDirty(x, y, z); } catch (Throwable ignored) { }
    }
}
