package com.luxurylighting;

import net.minecraftforge.fml.common.Mod;

/** Main class is intentionally empty and touches no client classes, so it can never fail on load. */
@Mod(LuxuryLighting.MODID)
public class LuxuryLighting {
    public static final String MODID = "luxurylighting";

    public LuxuryLighting() {
    }
}
