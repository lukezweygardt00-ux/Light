package com.luxurylighting.mixin;

import com.luxurylighting.client.DynamicLightManager;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
    /** Packed light = block << 4 | sky << 20. We only raise the block part using our own sources. */
    @Inject(method = "getLightColor(Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)I",
            at = @At("RETURN"), cancellable = true, require = 0)
    private static void luxurylighting$boost(BlockAndTintGetter level, BlockState state, BlockPos pos,
                                             CallbackInfoReturnable<Integer> cir) {
        try {
            int packed = cir.getReturnValue();
            int dyn = DynamicLightManager.levelAt(pos);
            if (dyn <= 0) return;
            int block = (packed >> 4) & 0xF;
            if (dyn > block) {
                cir.setReturnValue((packed & 0xFFFF0000) | (dyn << 4));
            }
        } catch (Throwable ignored) {
            // never let lighting break rendering (shader mods, Embeddium, etc.)
        }
    }
}
